/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package is.hi.mylla.utlit;



import is.hi.mylla.vinnsla.Mylla;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 * Viðmótshlutur sem teiknar mylluborð, býr til peð og meðhöndlar aðgerð þegar 
 * peð er sett á borð 
 * @author Ebba Þóra Hvannberg ebba@hi.is 
 * @date 
 * Háskóli Íslands
 */
public class MyllaPane extends Pane {

    private MyllaAdalController mAdal; 
    
    
    
    public MyllaPane () { 
        
    }
    
    public void leikmadurGerir(int leikmadur) {
        nyttPed(leikmadur);
    }

    // Vinnsluklasinn sem heldur utan um mylluborðið og leikmenn
    private final Mylla mittBord = new Mylla();
    
   /**
    * Teiknar grunnborð myllunnar á graphics context g. 
    * Er ekki að fullu útfært 
    * @param g 
    */
    public void teiknaGrunnbord(GraphicsContext g) {
        g.strokeLine(100,100,190,100);
        g.setStroke(Color.RED);
        g.strokeLine(100,120,190,120);
        
    }
    
    /**
     * Athugar á hvaða reit peð er, hvort peð er þegar á þeim reit setur peðið á
     * þann reit og athugar hvort það er vinningur.
     *
     * @param x x-gildi hnits
     * @param y y-gildi hnits
     */
    public void setjaABord(int x, int y) {

        mAdal.birtaVilluskilaboð("peð lendir á borði");
        
       
    }
    

    
    /**
     * Setur út nýtt peð fyrir leikmann l ef fjöldi peða hefur ekki náð hámarki
     *
     * @param l LEIKMADUR1 eða LEIKMADUR2
     */
    private void nyttPed(int l) {
        Ped s;
        if (l == 1) {
            s = new Ferningur(this, Color.RED);
        } else {
            s = new Hringur(this, Color.GREEN);
        }

        this.getChildren().add(s.getPed());
    }

    void setAdal(MyllaAdalController aThis) {
        mAdal = aThis;
    }
    
    
}
