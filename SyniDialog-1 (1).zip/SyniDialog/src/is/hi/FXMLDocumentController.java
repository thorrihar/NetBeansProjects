/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;


/**
 * Aðal Controller forritsins. Sér um valmyndir 
 * @author Ebba Þóra Hvannberg ebba@hi.is
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private DialogPaneController dialogController;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
  
    }

    /** 
     * Atburðarhandler fyrir Nýr leikur valmyndarstakið
     * Ræsir dialog sem biður um nöfn leikmanna
     * @param event 
     */
    @FXML
    private void nofnHandler(ActionEvent event) {
        dialogController.hvadHeitaLeikmenn();
    }
}
