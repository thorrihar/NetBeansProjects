
package is.hi.mylla.utlit;



import is.hi.mylla.vinnsla.Mylla;
import javafx.scene.layout.Pane;

/**
 * Viðmótshlutur sem teiknar mylluborð, býr til peð og meðhöndlar aðgerð þegar 
 * peð er sett á borð 
 * @author Ebba Þóra Hvannberg ebba@hi.is 
 * @date 
 * Háskóli Íslands
 */
public class MyllaPane extends Pane {

    private MyllaAdalController mAdal;
    
    
    public MyllaPane () { 
        
    }
    

    // Vinnsluklasinn sem heldur utan um mylluborðið og leikmenn
    private final Mylla mittBord = new Mylla();
    
   
    
    /**
     * Athugar á hvaða reit peð er, hvort peð er þegar á þeim reit setur peðið á
     * þann reit og athugar hvort það er vinningur.
     *
     * @param x x-gildi hnits
     * @param y y-gildi hnits
     */
    public void setjaABord(int x, int y) {

        mAdal.birtaVilluskilaboð("");  
       
    }
    

    
    /**
     * Setur út nýtt peð fyrir leikmann l (ferning eða hring) 
     * ef fjöldi peða hefur ekki náð hámarki
     * @param l LEIKMADUR1 eða LEIKMADUR2
     */
    private void nyttPed(int leikmadur) {
        // Forritun þessarar aðferðar er ólokið 
        Ped s;
        s = new Ferningur(this);
        this.getChildren().add(s.getPed());
    }

    /***
     * Frumstillir teningu í aðalcontroller 
     * @param aThis 
     */
    void setAdal(MyllaAdalController aThis) {
        mAdal = aThis;
    }

    
    
}
